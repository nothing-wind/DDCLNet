import numpy as np
import os
import glob
import datetime
import cv2

import torch
from PIL import Image
from torch.autograd import Variable
from torchvision import transforms

from config import CVPR2014_path, DUT_path, CTCUG_path, bdd_test, defocus_blur_test, same_test, chuk_samename, skin_diease_test
from misc import check_mkdir, crf_refine, AvgMeter, cal_precision_recall_mae, cal_fmeasure
#from model import  MinNet3a, Min_vgg16, Min_res18g, Min_res18a, Min_res18a_l0, Min_res18a_3, Min_res101, Min_res101_msrc
from model import minres18thres3rev

torch.manual_seed(2019)

# set which gpu to use
torch.cuda.set_device(0)

# the following two args specify the location of the file of trained model (pth extension)
# you should have the pth file in the folder './$ckpt_path$/$exp_name$'
ckpt_path = './ckpt'
exp_name = 'cjcabla'

args = {
    'snapshot': 'CA_10000',  # your snapshot filename (exclude extension name)
    'crf_refine': False,  # whether to use crf to refine results
    'save_results': True  # whether to save the resulting masks
}

img_transform = transforms.Compose([
    #transforms.Resize(1024, 1024),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
to_pil = transforms.ToPILImage()

#to_test = {'CVPR2014L2H4': CVPR2014_path}
#to_test = {'CVPR2014Fusion': CVPR2014_path}
#to_test = {'BR2NETSTEPHL_5': BR2NETSTEP_path}
to_test = {'DUT': defocus_blur_test}
#to_test = {'CUHK': chuk_samename}
#to_test = {'CTCUG': CTCUG_path}
loss_recod = {
    'loss1': 0.3,
    'loss2': 0.3,
    'loss3': 0.2,
    'loss4': 0.2
              }

def main():
    net = minres18thres3rev(1).cuda()

    print ('load snapshot \'%s\' for testing' % args['snapshot'])
    net.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot']+'_thres3reva_dut_b16-3.pth'), map_location='cuda:0'))
    #net.load_state_dict(torch.load(r'E:\dataset\BDD\code\progress\ckpt\cjc\CA_10000_thon_b16-2.pth', map_location='cuda:0'))
    net.eval()

    results = {}

    with torch.no_grad():

        #for name, root in to_test.iteritems():

            precision_record, recall_record, = [AvgMeter() for _ in range(256)], [AvgMeter() for _ in range(256)]
            mae_record = AvgMeter()
            name = 'DUT'
            #name = 'CUHK'
            #name = 'CTCUG'
            root = to_test[name]
            root1 = root + '\*'
            img_roots = glob.glob(root1)
            img_roots.sort()
            if args['save_results']:
                check_mkdir(os.path.join(ckpt_path, exp_name, '(%s) %s_%s' % (exp_name, name, args['snapshot']+'_thres3reva_16-3')))

            img_list = [os.path.splitext(f)[0] for f in os.listdir(root) if f.endswith('.jpg') or f.endswith('.JPG')]

            img_list.sort()
            idx = 0
            n = len(img_list)
            t0 = datetime.datetime.now()
            for  img_name , img_root in (zip(img_list, img_roots)):
                idx = idx+1
                print ('predicting for %s: %d / %d' % (name, idx + 1, len(img_list)))

                #img = cv2.imread(img_root)
                #img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img = Image.open(img_root).convert('RGB')
                img_var = Variable(img_transform(img).unsqueeze(0), volatile=True).cuda()
                #img_var = Variable(img_transform(img).unsqueeze(0), volatile=True).cuda()
                prediction = net(img_var)
                prediction = np.array(to_pil(prediction.data.squeeze(0).cpu()))

                if args['crf_refine']:
                    prediction = crf_refine(np.array(img), prediction)

                gt = np.array(Image.open(os.path.join(root, img_name + '.bmp').replace('DUT500S-Testing','DUT500GT-Testing')).convert('L'))
                #gt = np.array(Image.open(
                 #   os.path.join(root, img_name + '.png').replace('samename_CHUK', 'samename_CHUK_gt')).convert('L'))
                #gt = np.array(Image.open(
                 #   os.path.join(root, img_name + '.png').replace('Imgs', 'Gt')).convert('L'))
                #gt = cv2.resize(gt ,[1024, 10224])
                precision, recall, mae = cal_precision_recall_mae(prediction, gt)
                for pidx, pdata in enumerate(zip(precision, recall)):
                     p, r = pdata
                     precision_record[pidx].update(p)
                     recall_record[pidx].update(r)
                mae_record.update(mae)

                if args['save_results']:
                    Image.fromarray(prediction).save(os.path.join(ckpt_path, exp_name, '(%s) %s_%s' % (
                        exp_name, name, args['snapshot']+'_thres3reva_16-3'), img_name + '.png'))

            fmeasure = cal_fmeasure([precord.avg for precord in precision_record],
                                   [rrecord.avg for rrecord in recall_record])

            results[name] = {'fmeasure': fmeasure, 'mae': mae_record.avg}
            #results['perimg'] = (datetime.datetime.now()-t0)/n

    #print ('test results:')
    print (results)
    with open('./testlog.txt', 'a') as log:
        log.write(str(results)+'    '+'\n\n')
        log.flush()
        log.close()


if __name__ == '__main__':
    main()
