import datetime
import os

import torch
from torch import nn
from torch import optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms

import joint_transforms
from config import cvpr2014_trainning_path, bdd_train, defocus_blur, same_train, duts, skin_diease, chuk_samename, defocus_train
from datasets import ImageFolder, bddImageFolder
from misc import AvgMeter, check_mkdir
from model import minres18thres3rev

from torch.backends import cudnn

cudnn.benchmark = True

torch.manual_seed(2019)
torch.cuda.set_device(0)

ckpt_path = './ckpt'
exp_name = 'cjcabla'

args = {
    'iter_num': 10000,  #
    'train_batch_size': 16,
    'last_iter': 0 ,
    'lr': 1e-3,
    'lr_decay': 0.9,
    'weight_decay': 5e-4,
    'momentum': 0.9,
    'snapshot': ''
}

logname = 'thres3reva_CA_%d_dut_16-2' % args['iter_num']

joint_transform = joint_transforms.Compose([
    joint_transforms.RandomCrop(300),
    joint_transforms.RandomHorizontallyFlip(),
    joint_transforms.RandomRotate(10)
])
img_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
target_transform = transforms.ToTensor()

#train_set = ImageFolder(bdd_train, joint_transform, img_transform, target_transform)
#bddtrain_set = bddImageFolder(same_train, joint_transform, img_transform, target_transform)
bddtrain_set = bddImageFolder(defocus_blur, joint_transform, img_transform, target_transform)
#print(len(bddtrain_set))
#train_loader = DataLoader(train_set, batch_size=args['train_batch_size'], num_workers=12, shuffle=True)
train_loader = DataLoader(bddtrain_set, batch_size=args['train_batch_size'], num_workers=0, shuffle=True)

criterion = nn.BCEWithLogitsLoss().cuda()
#criterion = diceloss().cuda()
log_path = os.path.join(r'E:\dataset\BDD\code\progress\ckpt', exp_name, logname + '.txt')


def main():
    #net = BR2Net().cuda().train()
    net = minres18thres3rev(1).cuda().train()
    net.load_state_dict(torch.load('E:\dataset\BDD\code\progress\ckpt\cjcabla\CA_10000_thres3reva_b16-2.pth', map_location='cuda:0'))
    optimizer = optim.SGD([
        {'params': [param for name, param in net.named_parameters() if name[-4:] == 'bias'],
         'lr': 2 * args['lr']},
        {'params': [param for name, param in net.named_parameters() if name[-4:] != 'bias'],
         'lr': args['lr'], 'weight_decay': args['weight_decay']}
    ], momentum=args['momentum'])

    if len(args['snapshot']) > 0:
        print( 'training resumes from ' + args['snapshot'])
        net.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot'] + '.pth')))
        optimizer.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot'] + '_optim.pth')))
        optimizer.param_groups[0]['lr'] = 2 * args['lr']
        optimizer.param_groups[1]['lr'] = args['lr']

    check_mkdir(ckpt_path)
    check_mkdir(os.path.join(ckpt_path, exp_name))
    #open(log_path, 'w').write(str(args) + '\n\n')
    t0 = datetime.datetime.now()
    with open(log_path, 'a') as log:
        log.write(str(args) + '\n\n')
        train(net, optimizer, log)
        log.write(str(datetime.datetime.now()-t0)+'\n')


def train(net, optimizer, log):
    curr_iter = args['last_iter']
    while True:
        total_loss_record = AvgMeter()
        lossL2H1_record, lossL2H2_record, lossL2H3_record, lossL2H4_record = AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter()
        lossH2L1_record, lossH2L2_record, lossH2L3_record, lossH2L4_record = AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter()
        loss1_record, loss2_record, loss3_record, low_record, high_record, cont_record, loss_record = AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter() ,AvgMeter(), AvgMeter()
        #loss0_record, loss1_record, loss2_record, loss3_record = AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter()
        loss_record = AvgMeter()
        for i, data in enumerate(train_loader):
            optimizer.param_groups[0]['lr'] = 2 * args['lr'] * (1 - float(curr_iter) / args['iter_num']
                                                                ) ** args['lr_decay']
            optimizer.param_groups[1]['lr'] = args['lr'] * (1 - float(curr_iter) / args['iter_num']
                                                            ) ** args['lr_decay']

            inputs, labels = data
            batch_size = inputs.size(0)
            inputs = Variable(inputs).cuda()
            labels = Variable(labels).cuda()

            optimizer.zero_grad()
            #outputsH2L1, outputsH2L2, outputsH2L3, outputsH2L4, outputsL2H1, outputsL2H2, outputsL2H3, outputsL2H4, outputsFusion = net(inputs)
            #out1, out2, out3, out = net(inputs)
            outputsH2L1, outputsH2L2, outputsH2L3, outputsL2H1, outputsL2H2, outputsL2H3, out1, out2, outputsFusion = net(inputs)
            #lossL2H0 = criterion(outputsL2H0, labels)
            '''lossL2H1 = criterion(outputsL2H1, 1.0-labels)
            lossL2H2 = criterion(outputsL2H2, 1.0-labels)
            lossL2H3 = criterion(outputsL2H3, 1.0-labels)'''
            lossL2H1 = criterion(outputsL2H1,  1.0-labels)
            lossL2H2 = criterion(outputsL2H2,  1.0-labels)
            lossL2H3 = criterion(outputsL2H3,  1.0-labels)
            #lossL2H4 = criterion(outputsL2H4, 1.0-labels)

            #lossH2L0 = criterion(outputsH2L0, labels)
            lossH2L1 = criterion(outputsH2L1, 1.0-labels)
            lossH2L2 = criterion(outputsH2L2, 1.0-labels)
            lossH2L3 = criterion(outputsH2L3, 1.0-labels)
            #lossH2L4 = criterion(outputsH2L4, labels)

            lossFusion = criterion(outputsFusion, labels)
            loss1 = criterion(out1, labels)
            loss2 = criterion(out2, labels)
            '''loss = criterion(out, labels)
            loss3 = criterion(out3, labels)
            loss2 = criterion(out2, labels)
            loss1 = criterion(out1, labels)'''





            total_loss = lossFusion + lossL2H1 + lossL2H2 + lossL2H3 + lossH2L1 + lossH2L2 + lossH2L3
            #total_loss = loss1 + loss2 + loss3   + loss
            #total_loss =  4*(0.3*loss1 + 0.3*loss2 + 0.2*loss3 + 0.2*loss4)
            total_loss.backward()
            optimizer.step()

            total_loss_record.update(total_loss.item(), batch_size)
            '''loss1_record.update(loss1.item(), batch_size)
            loss2_record.update(loss2.item(), batch_size)
            loss3_record.update(loss3.item(), batch_size)
            loss_record.update(loss.item(), batch_size)'''

            #loss0_record.update(loss0.item(), batch_size)

            #lossH2L0_record.update(lossH2L0.item(), batch_size)
            lossH2L1_record.update(lossH2L1.item(), batch_size)
            lossH2L2_record.update(lossH2L2.item(), batch_size)
            lossH2L3_record.update(lossH2L3.item(), batch_size)
            #lossH2L4_record.update(lossH2L4.item(), batch_size)

            lossL2H1_record.update(lossL2H1.item(), batch_size)
            lossL2H2_record.update(lossL2H2.item(), batch_size)
            lossL2H3_record.update(lossL2H3.item(), batch_size)
            #lossL2H4_record.update(lossL2H4.item(), batch_size)
            loss_record.update(lossFusion.item(), batch_size)
            loss1_record.update(loss1.item(), batch_size)
            loss2_record.update(loss2.item(), batch_size)

            curr_iter += 1

            '''log1 = '[iter %d], [total loss %.5f], [loss %.5f],  [loss3 %.5f], [loss2 %.5f], [loss1 %.5f], [lr %.13f]'  % \
                   (curr_iter, total_loss_record.avg, loss_record.avg,  loss3_record.avg, loss2_record.avg,
                    loss1_record.avg,
                   optimizer.param_groups[1]['lr'])
            logWrite1 = '%d %.5f %.5f %.5f %.5f %.5f  ]' \
                  ' %.13f]' % \
                   (curr_iter, total_loss_record.avg, loss_record.avg, loss3_record.avg, loss2_record.avg,loss1_record.avg,
                   optimizer.param_groups[1]['lr'])'''

            '''log1 = '[iter %d], [total loss %.5f], [loss %.5f], [lossL4 %.5f], [lossL3 %.5f], [lossL2 %.5f], [lossL1 %.5f],' \
                   ' [lossH4 %.5f], [lossH3 %.5f], [lossH2 %.5f], [lossH1 %.5f],[lr %.13f]' % \
                   (curr_iter, total_loss_record.avg, loss_record.avg, lossH2L4_record.avg, lossH2L3_record.avg,
                    lossH2L2_record.avg, lossH2L1_record.avg, lossL2H4_record.avg, lossL2H3_record.avg, lossL2H2_record.avg,
                    lossL2H1_record.avg, optimizer.param_groups[1]['lr'])'''
            '''logWrite1 = '%d %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f ] %.13f]' % \
                        (curr_iter, total_loss_record.avg, loss_record.avg, lossH2L4_record.avg, lossH2L3_record.avg,
                    lossH2L2_record.avg, lossH2L1_record.avg, lossL2H4_record.avg, lossL2H3_record.avg, lossL2H2_record.avg,
                    lossL2H1_record.avg, optimizer.param_groups[1]['lr'])'''
            log1 = '[iter %d], [total loss %.5f], [loss %.5f], [loss1 %.5f], [lossL3 %.5f], [lossL2 %.5f], [lossL1 %.5f],' \
                   ' [loss2 %.5f], [lossH3 %.5f], [lossH2 %.5f], [lossH1 %.5f],[lr %.13f]' % \
                   (curr_iter, total_loss_record.avg, loss_record.avg, loss1_record.avg, lossH2L3_record.avg,
                    lossH2L2_record.avg, lossH2L1_record.avg, loss2_record.avg, lossL2H3_record.avg,
                    lossL2H2_record.avg,
                    lossL2H1_record.avg, optimizer.param_groups[1]['lr'])
            logWrite1 = '%d %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f %.5f ] %.13f]' % \
                        (curr_iter, total_loss_record.avg, loss_record.avg, loss1_record.avg, lossH2L3_record.avg,
                         lossH2L2_record.avg, lossH2L1_record.avg, loss2_record.avg, lossL2H3_record.avg,
                         lossL2H2_record.avg,
                         lossL2H1_record.avg, optimizer.param_groups[1]['lr'])
            print (log1)
            log.write(logWrite1 + '\n')
            log.flush()

            if curr_iter == args['iter_num']:
                torch.save(net.state_dict(), os.path.join(ckpt_path, exp_name, 'CA_%d_thres3reva_dut_b16-3.pth' % curr_iter))
                torch.save(optimizer.state_dict(),
                           os.path.join(ckpt_path, exp_name, 'CA_%d_optim_thres3reva_dut_b16-3.pth' % curr_iter))
                return


if __name__ == '__main__':
    main()
