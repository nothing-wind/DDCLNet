from resnext.resnext_101_32x4d_ import resnext_101_32x4d
import torch
from torch import nn
from resnext.config import resnext101_32_path
from torchvision.models.resnet import resnext101_32x8d, resnet18, resnet34
from torchvision.models.vgg import vgg19, vgg16


class ResNeXt101(nn.Module):
    def __init__(self):
        super(ResNeXt101, self).__init__()
        net = resnext_101_32x4d
        #net.load_state_dict(torch.load(resnext101_32_path))

        net = list(net.children())
        self.layer0 = nn.Sequential(*net[:4])
        self.layer1 = net[4]
        self.layer2 = net[5]
        self.layer3 = net[6]
        self.layer4 = net[7]

    def forward(self, x):
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)
        return layer4

class ResNeXt102(nn.Module):
    def __init__(self):
        super(ResNeXt102, self).__init__()
        net = resnext101_32x8d(pretrained=True)
        #net.load_state_dict(torch.load(resnext101_32_path))

        net = list(net.children())
        self.layer0 = nn.Sequential(*net[:4])
        self.layer1 = net[4]
        self.layer2 = net[5]
        self.layer3 = net[6]
        self.layer4 = net[7]

    def forward(self, x):
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)
        return layer4

class Resnet34(nn.Module):
    def __init__(self):
        super(Resnet34, self).__init__()
        net = resnet34(pretrained=True)
        #print(net)
        #net.load_state_dict(torch.load(resnext101_32_path))

        net = list(net.children())
        #print(net)
        self.layer0 = nn.Sequential(*net[:4])
        self.layer1 = net[4]
        self.layer2 = net[5]
        self.layer3 = net[6]
        self.layer4 = net[7]

    def forward(self, x):
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)
        return layer4

class Resnet18(nn.Module):
    def __init__(self):
        super(Resnet18, self).__init__()
        net = resnet18(pretrained=True)
        #print(net)
        #net.load_state_dict(torch.load(resnext101_32_path))

        net = list(net.children())
        #print(net)
        self.layer0 = nn.Sequential(*net[:4])
        self.layer1 = net[4]
        self.layer2 = net[5]
        self.layer3 = net[6]
        self.layer4 = net[7]

    def forward(self, x):
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)
        return layer4


class Vgg16(nn.Module):
    def __init__(self):
        super(Vgg16, self).__init__()
        self.vgg = vgg16(pretrained=True)
        #print(net)
        #net.load_state_dict(torch.load(resnext101_32_path))

        self.layer0 = self.vgg.features[0:4]
        self.layer1 = self.vgg.features[4:9]
        self.layer2 = self.vgg.features[9:18]
        self.layer3 = self.vgg.features[18:27]
        self.layer4 = self.vgg.features[27:36]

    def forward(self, x):
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)
        return layer4


if __name__ == '__main__':
    net = ResNeXt101()
    net2 = ResNeXt102()
    print(net2)
