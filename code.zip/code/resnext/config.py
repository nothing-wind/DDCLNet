from torchvision.models.resnet import resnext101_32x8d
resnext101_32_path = '/media/chang/D/BaiduYun/ProgramRunning/Saliency/R3NET/R3Net-master/resnext/resnext_101_32x4d.pth'
