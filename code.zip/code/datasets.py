import os
import os.path
import numpy as np
import cv2

import torch.utils.data as data
from PIL import Image

def randomHueSaturationValue(image, hue_shift_limit=(-180, 180),
                             sat_shift_limit=(-255, 255),
                             val_shift_limit=(-255, 255), u=0.5):
    if np.random.random() < u:
        #image = np.uint8(image)
        #plt.imshow(image)
        '''cv2.namedWindow("src")
        cv2.imshow("src", image)'''
        image = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)  #把图像转到HSV空间
        h, s, v = cv2.split(image)  #图像的HSV通道图 H代表色调，S代表饱和度，V代表明亮程度
        hue_shift = np.random.randint(hue_shift_limit[0], hue_shift_limit[1]+1)
        hue_shift = np.uint8(hue_shift)
        h += hue_shift
        sat_shift = np.random.uniform(sat_shift_limit[0], sat_shift_limit[1])
        s = cv2.add(s, sat_shift)  #对于大于255的用255来取值
        val_shift = np.random.uniform(val_shift_limit[0], val_shift_limit[1])
        v = cv2.add(v, val_shift)
        image = cv2.merge((h, s, v))  #图像通道的合并
        #image = cv2.merge((s, v))
        image = cv2.cvtColor(image, cv2.COLOR_HSV2RGB)
        #image = np.uint8(image)
        '''cv2.namedWindow("hsvc")
        cv2.imshow("hsvc", image)'''

    return image

def randomShiftScaleRotate(image, mask,
                           shift_limit=(-0.0, 0.0),
                           scale_limit=(-0.0, 0.0),
                           rotate_limit=(-0.0, 0.0),
                           aspect_limit=(-0.0, 0.0),
                           borderMode=cv2.BORDER_CONSTANT, u=0.5):
    if np.random.random() < u:
        '''image = np.uint8(image)
        # plt.imshow(image)
        cv2.namedWindow("src2")
        cv2.imshow("src2", image)
        #cv2.destroyWindow('src2')'''
        height, width, channel = image.shape

        angle = np.random.uniform(rotate_limit[0], rotate_limit[1])
        scale = np.random.uniform(1 + scale_limit[0], 1 + scale_limit[1])
        aspect = np.random.uniform(1 + aspect_limit[0], 1 + aspect_limit[1])
        sx = scale * aspect / (aspect ** 0.5)
        sy = scale / (aspect ** 0.5)
        dx = round(np.random.uniform(shift_limit[0], shift_limit[1]) * width)
        dy = round(np.random.uniform(shift_limit[0], shift_limit[1]) * height)

        cc = np.math.cos(angle / 180 * np.math.pi) * sx
        ss = np.math.sin(angle / 180 * np.math.pi) * sy
        rotate_matrix = np.array([[cc, -ss], [ss, cc]])

        box0 = np.array([[0, 0], [width, 0], [width, height], [0, height], ])
        box1 = box0 - np.array([width / 2, height / 2])
        box1 = np.dot(box1, rotate_matrix.T) + np.array([width / 2 + dx, height / 2 + dy])

        box0 = box0.astype(np.float32)
        box1 = box1.astype(np.float32)
        mat = cv2.getPerspectiveTransform(box0, box1)
        image = cv2.warpPerspective(image, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                    borderValue=(
                                        0, 0,
                                        0,))
        mask = cv2.warpPerspective(mask, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                   borderValue=(
                                       0, 0,
                                       0,))
        '''image = np.uint8(image)
        cv2.namedWindow("hsvc2")
        cv2.imshow("hsvc2", image)
        #cv2.destroyWindow('hsvc2')'''

    return image, mask


def make_dataset(root):
    img_list = [os.path.splitext(f)[0] for f in os.listdir(root) if f.endswith('.jpg')]
    return [(os.path.join(root, img_name + '.jpg'), os.path.join(root, img_name + '.png')) for img_name in img_list]

def bdd_make_dataset(root):
    img_list = [os.path.splitext(f)[0] for f in os.listdir(root) if f.endswith('.jpg') or f.endswith('.JPG')]
    return [os.path.join(root, img_name + '.jpg') for img_name  in img_list]


class ImageFolder(data.Dataset):
    # image and gt should be in the same folder and have same filename except extended name (jpg and png respectively)
    def __init__(self, root, joint_transform=None, transform=None, target_transform=None):
        self.root = root
        self.imgs = bdd_make_dataset(root)
        self.joint_transform = joint_transform
        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):
        img_path, gt_path = self.imgs[index]
        img = Image.open(img_path).convert('RGB')
        target = Image.open(gt_path).convert('L')
        if self.joint_transform is not None:
            img, target = self.joint_transform(img, target)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __len__(self):
        return len(self.imgs)

class bddImageFolder(data.Dataset):
    # image and gt should be in the same folder and have same filename except extended name (jpg and png respectively)
    def __init__(self, root, joint_transform=None, transform=None, target_transform=None):
        self.root = root
        self.imgs = bdd_make_dataset(root)
        self.joint_transform = joint_transform
        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):
        img_path= self.imgs[index]
        gt_path = img_path.replace('DUT600S_Training', 'DUT600GT_Training').replace('.jpg', '.bmp').replace('.JPG', '.bmp')
        #gt_path = img_path.replace('defocus_train', 'defocus_traingt').replace('.jpg', '.png').replace('.JPG','.png')
        #gt_path = img_path.replace('ISIC-2017_Training_Data', 'ISIC-2017_Training_Part1_GroundTruth')[:-4] + '_segmentation.png'
        img = Image.open(img_path).convert('RGB')
        target = Image.open(gt_path).convert('L')

        if self.joint_transform is not None:
            check_time = 10
            for i in range(check_time):
                image_t, target_t = self.joint_transform(img, target)
                if np.max(target_t) != np.min(target_t) or i == check_time - 1:
                    img = image_t
                    target = target_t
                    break
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)

        img = np.array(img)
        target = np.array(target)

        '''img = randomHueSaturationValue(img,
                                       hue_shift_limit=(-30, 30),
                                       sat_shift_limit=(-5, 5),
                                       val_shift_limit=(-15, 15))'''

        '''img, target = randomShiftScaleRotate(img, target,
                                             shift_limit=(-0.1, 0.1),
                                             scale_limit=(-0.1, 0.1),
                                             aspect_limit=(-0.1, 0.1),
                                             rotate_limit=(-0, 0))'''

        return img, target

    def __len__(self):
        return len(self.imgs)