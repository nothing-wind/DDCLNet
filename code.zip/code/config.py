# coding: utf-8
import os
# 数据集存放路径
defocus_blur = r'E:\dataset\DefocusBlur\DUT-DBD_Dataset\DUT600S_Training'
defocus_blur_test = r'E:\dataset\DefocusBlur\DUT-DBD_Dataset\DUT500S-Testing'

same_train = r'E:\dataset\BDD_new\defocus_train'
same_test = r'E:\dataset\BDD_new\defocus_test'

CTCUG_path = r'E:\dataset\CTCUG_data\Imgs'
