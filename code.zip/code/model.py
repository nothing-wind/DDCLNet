import torch
import torch.nn.functional as F
from torch import nn
import datetime
from torch.autograd import Variable

import torch
import torch.nn.functional as func
import torch.nn as nn
from torch.backends import cudnn

from resnext.resnext101 import ResNeXt101, ResNeXt102, Resnet18, Vgg16, Resnet34

class res3(nn.Module):
    def __init__(self, channel):
        super(res3, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.PReLU(),
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.PReLU()
        )

    def forward(self, x):
        x = self.conv(x)
        return x

class minres18thres3rev(torch.nn.Module):
    def __init__(self, skip_out):
        super(minres18thres3rev, self).__init__()
        resnext = Resnet18()
        self.layer0 = resnext.layer0
        self.layer1 = resnext.layer1
        self.layer2 = resnext.layer2
        self.layer3 = resnext.layer3
        self.layer4 = resnext.layer4

        self.conv0 = nn.Conv2d(64, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv1 = nn.Conv2d(64, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv2 = nn.Conv2d(128, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv3 = nn.Conv2d(256, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv4 = nn.Conv2d(512, skip_out, kernel_size=3, padding=1, bias=True)

        self.fea_low1 = res3(skip_out)
        self.fea_low2 = res3(skip_out)
        self.fea_low3 = res3(skip_out)
        #self.fea_low4 = res(skip_out)

        self.fea_high1 = res3(skip_out)
        self.fea_high2 = res3(skip_out)
        self.fea_high3 = res3(skip_out)
        #self.fea_high4 = res(skip_out)

        self.fea1 = res3(skip_out)
        self.fea2 = res3(skip_out)
        self.fea3 = res3(skip_out)


        #self.finnalconv = nn.Conv2d(skip_out, skip_out, kernel_size=3, padding=1, bias=True)
        #self.out1 =nn.Conv2d(skip_out, skip_out, kernel_size=3, padding=1, bias=True)
        #self.out2 = nn.Conv2d(skip_out, skip_out, kernel_size=3, padding=1, bias=True)
        #self.finnalfuse = res(skip_out)

    def forward(self, x):

        x_size = x.size()[2:]
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)

        #l0_size = layer0.size()[2:]
        #l4_size = layer4.size()[2:]
        l2_size = layer2.size()[2:]

        skip_4 = self.conv4(layer4)
        skip_3 = self.conv3(layer3)
        skip_2 = self.conv2(layer2)
        skip_1 = self.conv1(layer1)
        skip_0 = self.conv0(layer0)

        fea0 = func.interpolate(input=skip_0, size=l2_size, mode='bilinear')
        fea1 = func.interpolate(input=skip_1, size=l2_size, mode='bilinear')
        fea2 = func.interpolate(input=skip_2, size=l2_size, mode='bilinear')
        fea3 = func.interpolate(input=skip_3, size=l2_size, mode='bilinear')
        fea4 = func.interpolate(input=skip_4, size=l2_size, mode='bilinear')



        out_low1 = self.fea_low1(fea0+fea3)
        out_low2 = self.fea_low2(out_low1+fea2)
        out_low3 = self.fea_low3(out_low2+fea1)
        #out_low4 = self.fea_low4(out_low3+fea_low4)

        out_high1 = self.fea_high1(fea4 + fea3)
        out_high2 = self.fea_high2(out_high1 + fea2)
        out_high3 = self.fea_high3(out_high2 + fea1)
        #out_high4 = self.fea_high4(out_high3 + fea_high0)

        out1 = self.fea1(-out_high1+out_low1)
        out2 = self.fea2(out1-out_high2+out_low2)
        out3 = self.fea3(out2-out_high3+out_low3)


        #out_low4 = func.interpolate(input=out_low4, size=x_size, mode='bilinear')
        #out_high4 = func.interpolate(input=out_high4, size=x_size, mode='bilinear')

        #out = self.finnalconv(-out_high4 + out_low4)
        #out = self.finnalfuse(out)

        out_low1 = func.interpolate(input=out_low1, size=x_size, mode='bilinear')
        out_low2 = func.interpolate(input=out_low2, size=x_size, mode='bilinear')
        out_low3 = func.interpolate(input=out_low3, size=x_size, mode='bilinear')
        out_high1 = func.interpolate(input=out_high1, size=x_size, mode='bilinear')
        out_high2 = func.interpolate(input=out_high2, size=x_size, mode='bilinear')
        out_high3 = func.interpolate(input=out_high3, size=x_size, mode='bilinear')
        out3 = func.interpolate(input=out3, size=x_size, mode='bilinear')
        out2 = func.interpolate(input=out2, size=x_size, mode='bilinear')
        out1 = func.interpolate(input=out1, size=x_size, mode='bilinear')




        if self.training:
            return out_low1, out_low2, out_low3,  out_high1, out_high2, out_high3, out1, out2, out3
        return F.sigmoid(out3)